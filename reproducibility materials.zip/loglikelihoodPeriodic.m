function L = loglikelihoodPeriodic(theta, Tmax, times)
    mu = theta(1); alpha = theta(2); beta = theta(3); gamma = theta(4);
    L = - (mu+alpha)*Tmax - alpha/beta*(cos(beta*gamma)-cos(beta*(Tmax-gamma)));
    for t = times
        L = L + log(alpha*(sin(beta*(t-gamma))+1) + mu);
    end
    L = -L;
end