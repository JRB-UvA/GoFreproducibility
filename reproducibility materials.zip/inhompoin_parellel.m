simcount = 8; A=zeros(1,simcount);
Tmax = 5000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    %START OF SIMULATION PART
    tau = 0; times = [];
    lambdafun = @(t) (sin(t/5)+1.25);
    funmax = 2.25;
    while tau < Tmax
        T = exprnd(1/funmax);
        tau = tau + T;
        if tau <= Tmax && lambdafun(tau)/funmax > rand 
            times(end+1) = tau;
        end
    end
    %END OF SIMULATION PART

    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihood(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);

    maxtime = 0.9; 
    Z = []; W = [];
    for i = 0:n
        W(i+1) = Wtransformation(i*maxtime/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks] = kstest(Z);   
    
    A(j)=p_ks;
end
A