% CODE TO REPLICATE TABLES 1-3
simcount = 500; 
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount); 
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 5000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    %SIMULATING THE PROCESS, can be replaced by other sample path
    %simulations to test alternatives
    %START OF SIMULATION PART
    times = []; mu = 1/2; alpha = 1; beta = 2; tau = 0; 
    lambda = mu*beta/(beta-alpha); %start in (expected) stationarity

    while tau < Tmax
        T = exprnd(1/lambda);
        tau = tau + T;
        if rand > (mu+(lambda-mu)*exp(-beta*T))/lambda && tau <= Tmax
            lambda = mu+(lambda-mu)*exp(-beta*T); 
        elseif tau <= Tmax
            lambda = mu+(lambda-mu)*exp(-beta*T) + alpha;
            times(end+1) = tau;
        end
    end
    %END OF SIMULATION PART


    %ESTIMATING THE PARAMETERS
    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihood(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    
    %APPLYING NAIVE TESTING PROCEDURE
    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformation(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    
    %APPLYING ASYMPTOTICALLY EXACT TESTUNG PROCEDURE
    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformation(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformation(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;
    KSvaluesB(j) = v_ks;

    %plot(W)
    %plot(Z)

    j

end

rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]

%maxes=[max(B_ks) max(B_cm) max(B_ad) max(A_ks) max(A_cm) max(A_ad)]
% A = naive; B = transformed 





%TO REPLICATE FIGURE 1; FOR NAIVE PROCEDURE, REPLACE KSvaluesB BY KSvaluesA.
%Do the same thing after running the code for T=50000 to replicate figures
%C and D

%KSquantiles = zeros(1,500);
%for i = 1:500
%KSquantiles(i)=kolminv((i-0.5)/500);
%end

%qqplot(KSquantiles,Tmax^(1/4)*KSvaluesB)
%xlim([0,2.2])
%ylim([0,2.2])
%xlabel('Quantiles of Kolmogorov distribution')
%ylabel('Quantiles of KS test statistic')
%title('QQ Plot of KS test statistic vs. its asymptotic distribution under the null')
%hold on 
%plot(xlim,ylim,'-b')
%hold off


