maxtime = 0.9; 
n = round(Tmax/25); Z = []; W = [];
for i = 0:n
    W(i+1) = Wtransformation(i*maxtime/n,hatmu,hatalpha,hatbeta,Tmax,times);
end
for i = 1:n
    Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
end

dist = makedist('Normal');

[h_ks,p_ks] = kstest(Z) %already tests for STANDARD normal
%[h_ad,p_ad] = adtest(Z,'Distribution',dist)
%[h_cm,p_cm] = cmtest(Z,'CDF',dist)
%[h_ws,p_sw] = swtest(Z) %shapiro wilk, tests joint H0 of normality (not necessarily standard)