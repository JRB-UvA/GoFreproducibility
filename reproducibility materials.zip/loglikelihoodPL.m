function L = loglikelihoodPL(theta, Tmax, times)
    mu = theta(1); alpha = theta(2); beta = theta(3);
    n = length(times);
    easytimescount = Tmax-times>500; sumETC = sum(easytimescount); times2 = times;
    times2(easytimescount)=[];
    L = -mu*Tmax - alpha/beta*sumETC; 
    for i = [sumETC+1:n]
        L = L + alpha/beta * ((Tmax-times(i)+1)^(-beta)-1);
    end
    for i = [1:n]
        S = 0;
        for j = [max(1,i-500):(i-1)] %[1:(i-1)]
            S = S + (times(i)-times(j)+1)^(-beta-1);
        end
        L = L + log(mu+alpha*S);
    end
    L = -L;
end

