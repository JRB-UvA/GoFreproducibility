function Z = compensatorSchoenberg(T,hatmu,hatkappa,hatbeta, hatalpha, Tmax,times)
    toremove = times>T; times2 = times; times2(toremove)=[];
    Z = hatmu*T; m = length(times2);
    lambdavalues = [hatmu]; Hvalues = [hatkappa/hatmu^hatalpha];
    for i = 2:m
        lambdavalues(i) = hatmu + (lambdavalues(i-1)+hatbeta*Hvalues(i-1)-hatmu)*exp(-hatbeta*(times(i)-times(i-1)));
        Hvalues(i) = hatkappa/lambdavalues(i)^hatalpha;
    end
    for i = 1:m
        Z = Z + Hvalues(i)*(1-exp(-hatbeta*(T-times(i))));
    end
end


