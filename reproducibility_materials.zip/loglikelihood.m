function L = loglikelihood(theta, Tmax, times)
    mu = theta(1); alpha = theta(2); beta = theta(3);
    n = length(times);
    L = -mu*Tmax;
    for i = [1:length(times)]
        L = L + alpha/beta * (exp(-beta*(Tmax-times(i)))-1);
    end
    for i = [1:length(times)]
        S = 0;
        for j = [max(1,i-100):(i-1)]
            S = S + exp(-beta*(times(i)-times(j)));
        end
        L = L + log(mu+alpha*S);
    end
    L = -L;
end
