%TO REPLICATE SECOND PART OF TABLE 6
simcount = 500; 
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount); A_cm = zeros(1,simcount);  B_cm = zeros(1,simcount); 
A_ad = zeros(1,simcount);  B_ad = zeros(1,simcount); 
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
Tmax = 5000;
parfor j = 1:simcount
    %START OF SIMULATION PART
    tau = 0; times = [];
    lambdafun = @(t) (sin(t/5)+1.25);
    funmax = 2.25;
    while tau < Tmax
        T = exprnd(1/funmax);
        tau = tau + T;
        if tau <= Tmax && lambdafun(tau)/funmax > rand 
            times(end+1) = tau;
        end
    end

    %END OF SIMULATION PART

    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihoodPL(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);

    K=length(times); RTC=[]; RTCdif=[];
    for i = 1:K 
        RTC(i)=compensatorPL(times(i),hatmu,hatalpha,hatbeta,Tmax,times);
    end
    RTCdif(1)=RTC(1);
    RTCdif(2:K)=diff(RTC);
    distexp = makedist('Exponential');
    [h_ks_RTC,p_ks_RTC,v_ks,cv_ks] = kstest(RTCdif,'CDF',distexp);
    [h_ad,p_ad] = adtest(RTCdif,'Distribution',distexp);
    [h_cm,p_cm] = cmtest(RTCdif,'CDF',distexp);
    A_ks(j)=p_ks_RTC; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    hatalphaZ = (K-RTC(K))/sqrt(Tmax);
    RTCdifB = [RTCdif(1)+times(1)*hatalphaZ];
    for i = 2:K
        RTCdifB(end+1) = RTCdif(i) + (times(i)-times(i-1))*hatalphaZ;
    end
    [h_ks_RTC_B,p_ks_RTC_B,v_ks_B,cv_ks_B] = kstest(RTCdifB,'CDF',distexp);
    [h_ad,p_ad] = adtest(RTCdifB,'Distribution',distexp);
    [h_cm,p_cm] = cmtest(RTCdifB,'CDF',distexp);
    B_ks(j)=p_ks_RTC_B; B_ad(j)=p_ad; B_cm(j)=p_cm;
    KSvaluesB(j) = v_ks_B;

    j

end


%rejectionsBprop = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2)]/simcount
%rejectionsAprop = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2)]/simcount

%rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2)]
%rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2)]

rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]



KSquantiles = zeros(1,simcount);
for i = 1:simcount
KSquantiles(i)=kolminv((i-0.5)/simcount);
end

qqplot(KSquantiles,Tmax^(1/2)*KSvaluesB)
xlim([0,2.2])
ylim([0,2.2])
xlabel('Quantiles of Kolmogorov distribution')
ylabel('Quantiles of KS test statistic')
title('QQ Plot of KS test statistic vs. its asymptotic distribution under the null')
hold on 
plot(xlim,ylim,'-b')
hold off



