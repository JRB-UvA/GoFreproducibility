function Z = compensatorOgata(T,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes)
    toremove = times>T; times2 = times; times2(toremove)=[];
    Z = hatmu*T; m = length(times2);
    for k = 1:m
        Z = Z + exp(hatbeta*(magnitudes(k)-6))*hatK*reallog(1+(T-times(k))/hatc);
    end
end

%for i = 1:483 RTC(i)=compensatorOgata(times(i),hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes);end
%RTCdif(1)=RTC(1);
% RTCdif(2:483)=diff(RTC);
%distexp = makedist('Exponential')
%[h_ks,p_ad_RTC]= adtest(RTCdif,'Distribution','exp')
%[h_ks,p_ks_RTC] = kstest(RTCdif,'CDF',distexp)
%qqplot(RTCdif,distexp)
%xlim([0,7.5])
%ylim([0,7.5])
%xlabel('Quantiles of $\mathrm{Exp}(1)$-distribution','Interpreter','latex')
%ylabel('Quantiles of transformed interarrival times','Interpreter','latex')
%title('QQ Plot of transformed vs.\ Poisson interarrival times','Interpreter','latex')
%hold on 
%hold on 
%plot(xlim,ylim,'-b')
%hold off
%plot(RTC,1:483)
%plot(1:482,RTCdif)