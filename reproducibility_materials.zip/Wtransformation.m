function Z = Wtransformation(w,hatmu,hatalpha,hatbeta,Tmax,times)
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    Z = empiricaltransformation(w,hatmu,hatalpha,hatbeta,Tmax,times) / sqrt(mu_hattheta);
    emp1 = empiricaltransformation(1,hatmu,hatalpha,hatbeta,Tmax,times);
    fun = @(v) (emp1-empiricaltransformation(v,hatmu,hatalpha,hatbeta,Tmax,times))/(1-v);
    %q = integral(fun,0,w); 
    q=0; 
    N = max(1000,sqrt(Tmax)*20);  %higher N for more accuracy, lower N speeds up simulation
    for i = 1:N
        q = q + fun(i*w/(N+1))*w/N; % ad hoc trapezoid-like rule with step length w/N
    end
    Z = Z - q / sqrt(mu_hattheta);
end