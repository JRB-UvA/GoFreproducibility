function Z = empiricaltransformationPL(u,hatmu,hatalpha,hatbeta,Tmax,times)
    T = u*Tmax; toremove = times>T; times2 = times; times2(toremove)=[];
    easytimescount = T-times > 250; times3 = times2;
    times3(easytimescount)=[];
    integr = hatmu*T + hatalpha/hatbeta*sum(easytimescount);
    for t = times3
        integr = integr + hatalpha/hatbeta*(1-(1+T-t)^(-hatbeta));
    end
    Z = (length(times2)-integr)/sqrt(Tmax);
end