function Z = empiricaltransformationSchoenberg(u,hatmu,hatkappa,hatbeta, hatalpha, Tmax,times)
    T = u*Tmax;
    toremove = times>T; times2 = times; times2(toremove)=[];
    integr = hatmu*T; m = length(times2);
    lambdavalues = [hatmu]; Hvalues = [hatkappa/hatmu^hatalpha];
    for i = 2:m
        lambdavalues(i) = hatmu + (lambdavalues(i-1)+hatbeta*Hvalues(i-1)-hatmu)*exp(-hatbeta*(times(i)-times(i-1)));
        Hvalues(i) = hatkappa/lambdavalues(i)^hatalpha;
    end
    for i = 1:m
        integr = integr + Hvalues(i)*(1-exp(-hatbeta*(T-times(i))));
    end
    Z = (m-integr)/sqrt(Tmax);
end