%Import raw data Ogata1988dataRAW.xlsx, call it times and magnitudes
%times = times + rand(1,length(times)) to randomize time of onset over day

Tmax = 35064; % days between 1885 and 1980
mu_hattheta = length(times)/Tmax;
hatmu = .00536;  hatbeta = 1.61385; hatK = 0.017284; hatc = 0.01959;
n=6;
dist = makedist('Normal');
%n=round(sqrt(length(times))/4);

Z = []; W = [];
for i = 0:n
    W(i+1) = empiricaltransformationOgata(i/n,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes);
end
for i = 1:n
    Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
end
[h_ks1,p_ks1,v_ks,cv_ks] = kstest(Z);
[h_ad,p_ad1] = adtest(Z,'Distribution',dist);
[h_cm,p_cm1] = cmtest(Z,'CDF',dist);

maxtime = 0.9;
Z = []; W = [];

meshsize = 50; bigN = meshsize*n;
empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
emp1 = empiricaltransformationOgata(1,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes);
for i = 0:bigN
    empvalues(i+1) = empiricaltransformationOgata(i*maxtime/bigN,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes);
    empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
end

for i = 0:n
    q = 0; %q = integral(fun,0,w);
    A = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
    A = A / sqrt(mu_hattheta);
    W(i+1) = A;
end


for i = 1:n
    Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
end

[h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
[h_ad,p_ad] = adtest(Z,'Distribution',dist);
[h_cm,p_cm] = cmtest(Z,'CDF',dist);





%For Figure in earthquakes section
BigN2 = 1000; 
empvalues = zeros(1,bigN2+1); empvalues1 = empvalues;
emp1 = empiricaltransformationOgata(1,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes);
for i = 0:bigN2
    empvalues(i+1) = empiricaltransformationOgata(i*maxtime/bigN2,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes);
    empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN2);
end

TP = [];
for i = 0:bigN2
    TP(i+1) = (empvalues(i+1) - sum(empvalues1(1:(i+1)))/(i+1)*i*maxtime/bigN2) / sqrt(mu_hattheta);
end
A=linspace(0,maxtime,bigN2+1);
scatter(A,TP)
xlabel('Time','Interpreter','latex')
ylabel('Transformed empirical process','Interpreter','latex')
title('Path of compensated transformed earthquake data','Interpreter','latex')