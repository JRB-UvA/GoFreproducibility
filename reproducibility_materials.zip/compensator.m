function Z = compensator(u,hatmu,hatalpha,hatbeta,Tmax,times)
    T = u; toremove = times>T; times2 = times; times2(toremove)=[];
    easytimescount = T-times > 50/hatbeta; times3 = times2;
    times3(easytimescount)=[];
    integr = hatmu*T + hatalpha/hatbeta*sum(easytimescount); 
    for t = times3
        integr = integr + hatalpha/hatbeta*(1-exp(-hatbeta*(T-t)));
    end
    Z = integr;
end