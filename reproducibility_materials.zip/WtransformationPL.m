function Z = WtransformationPL(w,hatmu,hatalpha,hatbeta,Tmax,times)
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    Z = empiricaltransformationPL(w,hatmu,hatalpha,hatbeta,Tmax,times) / sqrt(mu_hattheta);
    emp1 = empiricaltransformationPL(1,hatmu,hatalpha,hatbeta,Tmax,times);
    fun = @(v) (emp1-empiricaltransformationPL(v,hatmu,hatalpha,hatbeta,Tmax,times))/(1-v);
    %q = integral(fun,0,w); 
    N = max(1000,Tmax); q=0; %higher N for more accuracy, lower N speeds up simulation
    for i = 1:N
        q = q + fun(i*w/(N+1))*w/N; % ad hoc trapezoid-like rule with step length w/N
    end
    Z = Z - q / sqrt(mu_hattheta);
end