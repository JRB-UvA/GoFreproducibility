% REPLICATE TABLE 1, seed is 23042025 (date of today)
delete(gcp('nocreate')) 
parpool('local', 8);             
masterSeed = 23042025;
simcount = 500;
mainStream = RandStream.create('mrg32k3a','Seed', masterSeed);
streams = cell(1, simcount); % THIS IS NEEDED TO SEED WITHIN THE PARALLEL COMPUTATIOS
for i = 1:simcount
    streams{i} = RandStream.create('mrg32k3a','Seed', masterSeed);
    streams{i}.Substream = i;
end

Table1 = zeros(18,6); %Columns contains number of rejection as found in the rows of Table 1
%Columns 1 to 6 correspond to ExpH, PLH, SN_{1,2,2}, SN_{1/5,10,2}, Periodic, SC
% Hence output can be seen as transpose of Table 1
% In the final line we output the Transpose of Table 1, hence Table 1
% itself
% run time on AMD Ryzen 5800H with 8 cores is approximately 15 minutes




%COLUMN 1, Exponential hawkes 
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount); 
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 5000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    RandStream.setGlobalStream(streams{j}); % THIS IS NEEDED TO SEED WITHIN THE PARALLEL COMPUTATIOS
    %SIMULATING THE PROCESS, can be replaced by other sample path
    %simulations to test alternatives
    %START OF SIMULATION PART
    times = []; mu = 1/2; alpha = 1; beta = 2; tau = 0; 
    lambda = mu*beta/(beta-alpha); %start in (expected) stationarity

    while tau < Tmax
        T = exprnd(1/lambda);
        tau = tau + T;
        if rand > (mu+(lambda-mu)*exp(-beta*T))/lambda && tau <= Tmax
            lambda = mu+(lambda-mu)*exp(-beta*T); 
        elseif tau <= Tmax
            lambda = mu+(lambda-mu)*exp(-beta*T) + alpha;
            times(end+1) = tau;
        end
    end
    %END OF SIMULATION PART


    %ESTIMATING THE PARAMETERS
    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihood(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    
    %APPLYING NAIVE TESTING PROCEDURE
    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformation(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    
    %APPLYING ASYMPTOTICALLY EXACT TESTING PROCEDURE
    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformation(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformation(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;
    KSvaluesB(j) = v_ks;

    %plot(W)
    %plot(Z)

    j

end

rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]

Table1(1:9,1) = rejectionsB; Table1(10:18,1) = rejectionsA;




delete(gcp('nocreate')) 
parpool('local', 8);             
masterSeed = 23042025+1;
mainStream = RandStream.create('mrg32k3a','Seed', masterSeed);
streams = cell(1, simcount);
for i = 1:simcount
    streams{i} = RandStream.create('mrg32k3a','Seed', masterSeed);
    streams{i}.Substream = i;
end


%COLUMN 2, Power law hawkes
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount); 
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 5000; n = round(sqrt(Tmax)/4); Tstationary = max(250,Tmax/250); Tmax2 = Tmax + Tstationary;
parfor j = 1:simcount
    RandStream.setGlobalStream(streams{j});
    %SIMULATING THE PROCESS, can be replaced by other sample path
    %simulations to test alternatives
    %START OF SIMULATION PART
    times = []; mu = 1/2; alpha = 1; beta = 2; tau = 0; lambda = mu;

    while tau < Tstationary
        T = exprnd(1/lambda);
        tau = tau + T;
        newlambda = mu;
        for t = times
            newlambda = newlambda + alpha*(1+tau-t)^(-1-beta);
        end
        if rand > newlambda/lambda && tau <= Tstationary
            lambda = newlambda; 
        elseif tau <= Tstationary
            lambda = newlambda + alpha;
            times(end+1) = tau;
        end
    end
    times2 = times;
    while tau < Tmax2
        T = exprnd(1/lambda);
        tau = tau + T;
        newlambda = mu;
        for t = times2
            newlambda = newlambda + alpha*(1+tau-t)^(-1-beta);
        end
        if rand > newlambda/lambda && tau <= Tmax2
            lambda = newlambda; 
        elseif tau <= Tmax2
            lambda = newlambda + alpha;
            times(end+1) = tau; times2(1) = []; times2(end+1) = tau; 
        end
    end
    toremove = times<Tstationary; times(toremove)=[]; times = times - Tstationary;

    %END OF SIMULATION PART


    %ESTIMATING THE PARAMETERS
    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihood(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    
    %APPLYING NAIVE TESTING PROCEDURE
    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformation(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    
    %APPLYING ASYMPTOTICALLY EXACT TESTING PROCEDURE
    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformation(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformation(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;
    KSvaluesB(j) = v_ks;

    %plot(W)
    %plot(Z)

    j

end

rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]

Table1(1:9,2) = rejectionsB; Table1(10:18,2) = rejectionsA;




delete(gcp('nocreate')) 
parpool('local', 8);             
masterSeed = 23042025+2;
mainStream = RandStream.create('mrg32k3a','Seed', masterSeed);
streams = cell(1, simcount);
for i = 1:simcount
    streams{i} = RandStream.create('mrg32k3a','Seed', masterSeed);
    streams{i}.Substream = i;
end


%COLUMN 3, SN_{1,2,2} (shot noise)
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount); 
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 5000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount  
    RandStream.setGlobalStream(streams{j});
    %SIMULATING THE PROCESS, can be replaced by other sample path
    %simulations to test alternatives
    %START OF SIMULATION PART
    times = []; mu = 1; alpha = 2; beta = 2; tau = 0;
    lambda = mu*alpha/beta; %start in (expected) stationarity

    while tau < Tmax
        T = exprnd(1/(lambda+mu));
        tau = tau + T;
        if rand > lambda/(lambda+mu) && tau <= Tmax
            lambda = alpha+lambda*exp(-beta*T);
        elseif rand < exp(-beta*T) && tau <= Tmax
            times(end+1) = tau;
            lambda = lambda*exp(-beta*T);
        elseif tau <= Tmax
            lambda = lambda*exp(-beta*T);
        end
    end
    %END OF SIMULATION PART


    %ESTIMATING THE PARAMETERS
    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihood(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    
    %APPLYING NAIVE TESTING PROCEDURE
    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformation(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    
    %APPLYING ASYMPTOTICALLY EXACT TESTING PROCEDURE
    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformation(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformation(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;
    KSvaluesB(j) = v_ks;

    %plot(W)
    %plot(Z)

    j

end

rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]

Table1(1:9,3) = rejectionsB; Table1(10:18,3) = rejectionsA;










delete(gcp('nocreate')) 
parpool('local', 8);             
masterSeed = 23042025+3;
mainStream = RandStream.create('mrg32k3a','Seed', masterSeed);
streams = cell(1, simcount);
for i = 1:simcount
    streams{i} = RandStream.create('mrg32k3a','Seed', masterSeed);
    streams{i}.Substream = i;
end

 
%COLUMN 4, SN_{1/5,10,2} (shot noise)
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount); 
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 5000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount    
    RandStream.setGlobalStream(streams{j});
    %SIMULATING THE PROCESS, can be replaced by other sample path
    %simulations to test alternatives
    %START OF SIMULATION PART
    times = []; mu = 1/5; alpha = 10; beta = 2; tau = 0;
    lambda = mu*alpha/beta; %start in (expected) stationarity

    while tau < Tmax
        T = exprnd(1/(lambda+mu));
        tau = tau + T;
        if rand > lambda/(lambda+mu) && tau <= Tmax
            lambda = alpha+lambda*exp(-beta*T);
        elseif rand < exp(-beta*T) && tau <= Tmax
            times(end+1) = tau;
            lambda = lambda*exp(-beta*T);
        elseif tau <= Tmax
            lambda = lambda*exp(-beta*T);
        end
    end
    %END OF SIMULATION PART


    %ESTIMATING THE PARAMETERS
    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihood(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    
    %APPLYING NAIVE TESTING PROCEDURE
    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformation(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    
    %APPLYING ASYMPTOTICALLY EXACT TESTING PROCEDURE
    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformation(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformation(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;
    KSvaluesB(j) = v_ks;

    %plot(W)
    %plot(Z)

    j

end

rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]

Table1(1:9,4) = rejectionsB; Table1(10:18,4) = rejectionsA;









delete(gcp('nocreate')) 
parpool('local', 8);             
masterSeed = 23042025+4;
mainStream = RandStream.create('mrg32k3a','Seed', masterSeed);
streams = cell(1, simcount);
for i = 1:simcount
    streams{i} = RandStream.create('mrg32k3a','Seed', masterSeed);
    streams{i}.Substream = i;
end


%COLUMN 5, Periodic poisson
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount); 
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 5000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    RandStream.setGlobalStream(streams{j});
    %SIMULATING THE PROCESS, can be replaced by other sample path
    %simulations to test alternatives
    %START OF SIMULATION PART
    tau = 0; times = [];
    lambdafun = @(t) (sin(t/5)+1.25);
    funmax = 2.25;
    while tau < Tmax
        T = exprnd(1/funmax);
        tau = tau + T;
        if tau <= Tmax && lambdafun(tau)/funmax > rand 
            times(end+1) = tau;
        end
    end
    %END OF SIMULATION PART


    %ESTIMATING THE PARAMETERS
    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihood(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    
    %APPLYING NAIVE TESTING PROCEDURE
    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformation(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    
    %APPLYING ASYMPTOTICALLY EXACT TESTING PROCEDURE
    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformation(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformation(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;
    KSvaluesB(j) = v_ks;

    %plot(W)
    %plot(Z)

    j

end

rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]

Table1(1:9,5) = rejectionsB; Table1(10:18,5) = rejectionsA;














delete(gcp('nocreate')) 
parpool('local', 8);             
masterSeed = 23042025+5;
mainStream = RandStream.create('mrg32k3a','Seed', masterSeed);
streams = cell(1, simcount);
for i = 1:simcount
    streams{i} = RandStream.create('mrg32k3a','Seed', masterSeed);
    streams{i}.Substream = i;
end



%COLUMN 6, Self correcting
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount); 
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 5000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    RandStream.setGlobalStream(streams{j});
    %SIMULATING THE PROCESS, can be replaced by other sample path
    %simulations to test alternatives
    %START OF SIMULATION PART
    tau = 0; times = []; alpha = 1/2; beta = log(2); lambda = 1;
    E = exp(1); 
    while tau < Tmax
        T = exprnd(1/lambda*E^beta);
        if T > 1
            tau = tau + 1; lambda = lambda * E^beta;
        else
            tau = tau + T;
            if tau <= Tmax
                lambda = lambda * exp(beta*T) * alpha;
                times(end+1) = tau;
            end
        end
    end
    %END OF SIMULATION PART


    %ESTIMATING THE PARAMETERS
    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihood(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);
    
    %APPLYING NAIVE TESTING PROCEDURE
    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformation(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    
    %APPLYING ASYMPTOTICALLY EXACT TESTING PROCEDURE
    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformation(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformation(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;
    KSvaluesB(j) = v_ks;

    %plot(W)
    %plot(Z)

    j

end

rejectionsB = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]

Table1(1:9,6) = rejectionsB; Table1(10:18,6) = rejectionsA;












Table1.'


