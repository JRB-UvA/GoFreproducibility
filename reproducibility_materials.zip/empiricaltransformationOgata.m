function Z = empiricaltransformationOgata(u,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes)
    T = u*Tmax; toremove = times>T; times2 = times; times2(toremove)=[];
    integr = hatmu*T; m = length(times2);
    for k = 1:m
        integr = integr + exp(hatbeta*(magnitudes(k)-6))*hatK*reallog(1+(T-times(k))/hatc);
    end
    Z = (m-integr)/sqrt(Tmax);
end
