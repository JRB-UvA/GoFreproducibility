function L = loglikelihoodSchoenberg(theta, Tmax, times)
    mu = theta(1); kappa = theta(2); beta = theta(3); alpha = theta(4);
    Z = mu*Tmax; m = length(times);
    lambdavalues = [mu]; Hvalues = [kappa/mu^alpha];
    for i = 2:m
        lambdavalues(i) = mu + (lambdavalues(i-1)+beta*Hvalues(i-1)-mu)*exp(-beta*(times(i)-times(i-1)));
        Hvalues(i) = kappa/lambdavalues(i)^alpha;
    end
    for i = 1:m
        Z = Z + Hvalues(i)*(1-exp(-beta*(Tmax-times(i))));
    end

    for i = 1:m
        Z = Z - log(lambdavalues(i));
    end
    L = Z;
end