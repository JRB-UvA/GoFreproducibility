function Z = WtransformationOgata(w,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes)
    mu_hattheta = length(times)/Tmax;
    Z = empiricaltransformationOgata(w,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes) / sqrt(mu_hattheta);
    emp1 = empiricaltransformationOgata(1,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes);
    fun = @(v) (emp1-empiricaltransformationOgata(v,hatmu,hatbeta,hatK, hatc, Tmax,times,magnitudes))/(1-v);
    %q = integral(fun,0,w); 
    q=0; N = 1000;  %higher N for more accuracy, lower N speeds up simulation
    for i = 1:N
        q = q + fun(i*w/(N+1))*w/N; % ad hoc trapezoid-like rule with step length w/N
    end
    Z = Z - q / sqrt(mu_hattheta);
end