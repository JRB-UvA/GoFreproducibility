function Z = empiricaltransformationPeriodic(u,hatmu,hatalpha,hatbeta,hatgamma,Tmax,times)
    T = u*Tmax; toremove = times>T; times2 = times; times2(toremove)=[];
    integr = hatalpha/hatbeta*(cos(hatbeta*hatgamma)-cos(hatbeta*(Tmax-hatgamma))) + (hatmu+hatalpha)*T;
    Z = (length(times2)-integr)/sqrt(Tmax);
end