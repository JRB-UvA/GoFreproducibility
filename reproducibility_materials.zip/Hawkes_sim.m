times = []; mu = 1; alpha = 1; beta = 2; tau = 0; Tmax = 2000;
lambda = mu*beta/(beta-alpha); %start in (expected) stationarity

while tau < Tmax
    T = exprnd(1/lambda);
    tau = tau + T;
    if rand > (mu+(lambda-mu)*exp(-beta*T))/lambda && tau <= Tmax
        lambda = mu+(lambda-mu)*exp(-beta*T); 
    elseif tau <= Tmax
        lambda = mu+(lambda-mu)*exp(-beta*T) + alpha;
        times(end+1) = tau;
    end
end

x = Tmax; y = times;
LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
logL = @(theta) loglikelihood(theta,x,y);
[x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB)

hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);

