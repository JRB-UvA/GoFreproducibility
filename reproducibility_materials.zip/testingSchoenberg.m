% import raw data as column vectors timesraw1 and counts

timesraw = [];
for i = 1:length(timesraw1)
    for j=1:counts(i)
        timesraw(end+1) = timesraw1(i);
    end
end

Tmin = 0;
times = sort(timesraw + 7*rand(1,length(timesraw))) - Tmin;
Tmax = 18993 - Tmin;
mu_hattheta = length(times)/Tmax;
    x = Tmax; y = times;
    LB=[0,0,0,0]; UB = [.5,5,5,2]; x0 = [.000139,.00205,.00151,1.09];
    logL = @(theta) loglikelihoodSchoenberg(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatkappa = hattheta(2); hatbeta = hattheta(3); hatalpha = hattheta(4);
    x1

%    x = Tmax; y = times;
%    LB=[0,0,0,0]; UB = [.1,1,1,2]; x0 = [.000139,.00205,.00151,1.09];
%    logL = @(theta) loglikelihoodSchoenberg(theta,x,y);
%    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

%    hattheta = x1; hatmu = hattheta(1); hatkappa = hattheta(2); hatbeta =
%    hattheta(3); hatalpha = hattheta(4);

%hatmu = 0.000139; hatkappa = 0.00205; hatbeta = 0.00151; hatalpha = 1.09;


n=max(6,round(sqrt(length(times))/4));
dist = makedist('Normal');

Z = []; W = [];
for i = 0:n
    W(i+1) = empiricaltransformationSchoenberg(i/n,hatmu,hatkappa,hatbeta, hatalpha, Tmax,times);
end
for i = 1:n
    Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
end
%naive testing procedure
[h_ks1,p_ks1,v_ks,cv_ks] = kstest(Z);
[h_ad,p_ad1] = adtest(Z,'Distribution',dist);
[h_cm,p_cm1] = cmtest(Z,'CDF',dist);

maxtime = 0.9;
Z = []; W = [];

meshsize = 50; bigN = meshsize*n;
empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
emp1 = empiricaltransformationSchoenberg(1,hatmu,hatkappa,hatbeta, hatalpha, Tmax,times);
for i = 0:bigN
    empvalues(i+1) = empiricaltransformationSchoenberg(i*maxtime/bigN,hatmu,hatkappa,hatbeta, hatalpha, Tmax,times);
    empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
end



for i = 0:n
    q = 0; %q = integral(fun,0,w);
    A = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
    A = A / sqrt(mu_hattheta);
    W(i+1) = A;
end


for i = 1:n
    Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
end
%testing procedure based on transformation
[h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
[h_ad,p_ad] = adtest(Z,'Distribution',dist);
[h_cm,p_cm] = cmtest(Z,'CDF',dist);





RTC=[]; RTCdif=[];
for i = 1:length(times) 
    RTC(i)=compensatorSchoenberg(times(i),hatmu,hatkappa,hatbeta, hatalpha, Tmax,times);
end
RTCdif(1)=RTC(1);
RTCdif(2:length(times))=diff(RTC);
distexp = makedist('Exponential');
[h_ad,p_ad_RTC]= adtest(RTCdif,'Distribution','exp');
[h_ks,p_ks_RTC] = kstest(RTCdif,'CDF',distexp);
%For cramer-von mises, first transform standard exponential to standard
%normal
A = norminv(expcdf(RTCdif));
dist = makedist('Normal');
[h_cm,p_cm_RTC] = cmtest(A,'CDF',dist);


%THE NEXT COMMANDS CAN BE RUN TO PLOT FIGURE 3
%FIGURE A

%K=length(times);
%for i = 1:K RTC(i)=compensatorSchoenberg(times(i),hatmu,hatkappa,hatbeta, hatalpha, Tmax,times);end
%RTCdif(1)=RTC(1);
% RTCdif(2:K)=diff(RTC);
%distexp = makedist('Exponential')
%[h_ks,p_ad_RTC]= adtest(RTCdif,'Distribution','exp')
%[h_ks,p_ks_RTC] = kstest(RTCdif,'CDF',distexp)
%hqq = qqplot(RTCdif,distexp)
%set(hqq, 'Color', 'w')
%xlim([0,5.2])
%ylim([0,5.2])
%xlabel('Quantiles of $\mathrm{Exp}(1)$-distribution','Interpreter','latex')
%ylabel('Quantiles of transformed interarrival times','Interpreter','latex')
%title('QQ Plot of transformed interarrival times vs.\ $\mathrm{Exp}(1)$-distribution','Interpreter','latex')
%hold on 
%plot(xlim,ylim,'-b','Color','red')
%hold off






%THIS COMMENTED PART CAN BE RUN TO GRAPH PATH OF COMPENSATED EMPIRICAL
%PROCESS

%BigN2 = 1000;
%empvalues = zeros(1,bigN2+1); empvalues1 = empvalues;
%emp1 = empiricaltransformationSchoenberg(1,hatmu,hatkappa,hatbeta, hatalpha, Tmax,times);
%for i = 0:bigN
%    empvalues(i+1) = empiricaltransformationSchoenberg(i*maxtime/bigN2,hatmu,hatkappa,hatbeta, hatalpha, Tmax,times);
%    empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN2);
%end
%TP = [];
%for i = 0:bigN2
%    TP(i+1) = (empvalues(i+1) - sum(empvalues1(1:(i+1)))/(i+1)*i*maxtime/bigN2) / sqrt(mu_hattheta);
%end
%A=linspace(0,maxtime,bigN2+1);
%plot(A,TP)
%xlabel('Time','Interpreter','latex')
%ylabel('Transformed empirical process','Interpreter','latex')
%title('Path of compensated RMSF data','Interpreter','latex')