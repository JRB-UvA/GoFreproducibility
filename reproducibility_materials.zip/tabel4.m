simcount = 500;
% A = naive; B = transformed 
A_ks = zeros(1,simcount); B_ks = zeros(1,simcount);
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 50000; Tstationary = max(250,Tmax/250); Tmax2 = Tmax + Tstationary; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    times = []; mu = 1/2; alpha = 1; beta = 2; tau = 0; lambda = mu;

    while tau < Tstationary
        T = exprnd(1/lambda);
        tau = tau + T;
        newlambda = mu;
        for t = times
            newlambda = newlambda + alpha*(1+tau-t)^(-1-beta);
        end
        if rand > newlambda/lambda && tau <= Tstationary
            lambda = newlambda; 
        elseif tau <= Tstationary
            lambda = newlambda + alpha;
            times(end+1) = tau;
        end
    end
    times2 = times;
    while tau < Tmax2
        T = exprnd(1/lambda);
        tau = tau + T;
        newlambda = mu;
        for t = times2
            newlambda = newlambda + alpha*(1+tau-t)^(-1-beta);
        end
        if rand > newlambda/lambda && tau <= Tmax2
            lambda = newlambda; 
        elseif tau <= Tmax2
            lambda = newlambda + alpha;
            times(end+1) = tau; times2(1) = []; times2(end+1) = tau; 
        end
    end
    toremove = times<Tstationary; times(toremove)=[]; times = times - Tstationary;

    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihoodPL(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);

    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformationPL(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformationPL(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;    
    KSvaluesB(j) = v_ks;
    [j 1]
end

rejectionsB_PLH = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA_PLH = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]







A_ks = zeros(1,simcount); B_ks = zeros(1,simcount);
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 50000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    times = []; mu = 1/2; alpha = 1; beta = 2; tau = 0; 
    lambda = mu*beta/(beta-alpha); %start in (expected) stationarity

    while tau < Tmax
        T = exprnd(1/lambda);
        tau = tau + T;
        if rand > (mu+(lambda-mu)*exp(-beta*T))/lambda && tau <= Tmax
            lambda = mu+(lambda-mu)*exp(-beta*T); 
        elseif tau <= Tmax
            lambda = mu+(lambda-mu)*exp(-beta*T) + alpha;
            times(end+1) = tau;
        end
    end

    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihoodPL(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);

    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformationPL(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformationPL(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;    
    KSvaluesB(j) = v_ks;
    [j 2]
end

rejectionsB_ExpH = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA_ExpH = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]











A_ks = zeros(1,simcount); B_ks = zeros(1,simcount);
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 50000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    times = []; mu = 1; alpha = 2; beta = 2; tau = 0;
    lambda = mu*alpha/beta; %start in (expected) stationarity

    while tau < Tmax
        T = exprnd(1/(lambda+mu));
        tau = tau + T;
        if rand > lambda/(lambda+mu) && tau <= Tmax
            lambda = alpha+lambda*exp(-beta*T);
        elseif rand < exp(-beta*T) && tau <= Tmax
            times(end+1) = tau;
            lambda = lambda*exp(-beta*T);
        elseif tau <= Tmax
            lambda = lambda*exp(-beta*T);
        end
    end

    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihoodPL(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);

    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformationPL(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformationPL(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;    
    KSvaluesB(j) = v_ks;
    [j 3]
end

rejectionsB_SN1 = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA_SN1 = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]














A_ks = zeros(1,simcount); B_ks = zeros(1,simcount);
A_ad = zeros(1,simcount); B_ad = zeros(1,simcount);
A_cm = zeros(1,simcount); B_cm = zeros(1,simcount);
KSvaluesA = zeros(1,simcount); KSvaluesB = zeros(1,simcount);
dist = makedist('Normal');
Tmax = 50000; n = round(sqrt(Tmax)/4);
parfor j = 1:simcount
    times = []; mu = 1/5; alpha = 10; beta = 2; tau = 0;
    lambda = mu*alpha/beta; %start in (expected) stationarity

    while tau < Tmax
        T = exprnd(1/(lambda+mu));
        tau = tau + T;
        if rand > lambda/(lambda+mu) && tau <= Tmax
            lambda = alpha+lambda*exp(-beta*T);
        elseif rand < exp(-beta*T) && tau <= Tmax
            times(end+1) = tau;
            lambda = lambda*exp(-beta*T);
        elseif tau <= Tmax
            lambda = lambda*exp(-beta*T);
        end
    end

    x = Tmax; y = times;
    LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
    logL = @(theta) loglikelihoodPL(theta,x,y);
    [x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB);

    hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
    mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);

    Z = []; W = [];
    for i = 0:n
        W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    end
    for i = 1:n
        Z(i) = sqrt(n)*(W(i+1)-W(i))  / sqrt(mu_hattheta);
    end
    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    A_ks(j)=p_ks; A_ad(j)=p_ad; A_cm(j)=p_cm;
    KSvaluesA(j) = v_ks;

    maxtime = 0.9; 
    Z = []; W = [];
    
    meshsize = 50; bigN = meshsize*n;
    empvalues = zeros(1,bigN+1); empvalues1 = empvalues;
    emp1 = empiricaltransformationPL(1,hatmu,hatalpha,hatbeta,Tmax,times);
    for i = 0:bigN
        empvalues(i+1) = empiricaltransformationPL(i*maxtime/bigN,hatmu,hatalpha,hatbeta,Tmax,times);
        empvalues1(i+1) = (emp1-empvalues(i+1))/(1-i*maxtime/bigN);
    end
    
    for i = 0:n
        q = 0; %q = integral(fun,0,w);
        Z = empvalues(meshsize*i+1) - sum(empvalues1(1:(i*meshsize+1)))/(i*meshsize+1)*i*maxtime/n;
        Z = Z / sqrt(mu_hattheta);
        W(i+1) = Z;
    end

    %    for i = 0:n
    %    W(i+1) = empiricaltransformationPL(i/n,hatmu,hatalpha,hatbeta,Tmax,times);
    %end
    
    for i = 1:n
        Z(i) = sqrt(n/maxtime)*(W(i+1)-W(i));
    end

    [h_ks,p_ks,v_ks,cv_ks] = kstest(Z);
    [h_ad,p_ad] = adtest(Z,'Distribution',dist);
    [h_cm,p_cm] = cmtest(Z,'CDF',dist);
    B_ks(j)=p_ks; B_ad(j)=p_ad; B_cm(j)=p_cm;    
    KSvaluesB(j) = v_ks;
    [j 4]
end

rejectionsB_SN2 = [sum(B_ks<.01) sum(B_ks<.05) sum(B_ks<.2) sum(B_cm<.01) sum(B_cm<.05) sum(B_cm<.2) sum(B_ad<.01) sum(B_ad<.05) sum(B_ad<.2)]
rejectionsA_SN2 = [sum(A_ks<.01) sum(A_ks<.05) sum(A_ks<.2) sum(A_cm<.01) sum(A_cm<.05) sum(A_cm<.2) sum(A_ad<.01) sum(A_ad<.05) sum(A_ad<.2)]
