times = []; mu = 1; alpha = 1; beta = 2; tau = 0; Tmax = 5000;
lambda = mu*alpha/beta; %start in (expected) stationarity

while tau < Tmax
    T = exprnd(1/(lambda+mu));
    tau = tau + T;
    if rand > lambda/(lambda+mu) && tau <= Tmax
        lambda = mu+lambda*exp(-beta*T);
    elseif rand < exp(-beta*T) && tau <= Tmax
        times(end+1) = tau;
        lambda = lambda*exp(-beta*T);
    elseif tau <= Tmax
        lambda = lambda*exp(-beta*T);
    end
end

x = Tmax; y = times;
LB=[0,0,0]; UB = [20, 20, 20]; x0 = [3,0.5,1];
logL = @(theta) loglikelihood(theta,x,y);
[x1,fval] = fmincon(logL,x0,[],[],[],[],LB,UB)

hattheta = x1; hatmu = hattheta(1); hatalpha = hattheta(2); hatbeta = hattheta(3);
mu_hattheta = hatmu*hatbeta/(hatbeta-hatalpha);

